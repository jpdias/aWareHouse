### aWareHouse
Control System for Servers WareHouses

#### DEMO: [aWareHouse](http://jpdias.noip.me:8080)

* [Duarte Duarte](http://github.com/dduarte) 
* [Hugo Freixo](http://github.com/freixo) 
* [João Pedro Dias](http://github.com/jpdias) 
